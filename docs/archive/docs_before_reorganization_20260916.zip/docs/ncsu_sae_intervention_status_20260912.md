# NCSU SAE 后续干预完成状态

更新日期：2026-09-13（America/New_York）。实验于 9 月 12 日启动，独立名称为 `ncsu_sae_intervention_v1`；文件名保留启动日期。

**教师干预、全量候选生成、24 个学生 adapter、25 组完整评估及交付复核均已完成。教师输出明显缩短，但尚未确立 SAE 相对无干预蒸馏的学生准确率收益。**

最终分析作业 `817324` 于 **2026-09-13 00:18:08 EDT** 成功结束。登记的 42 个作业全部为 `COMPLETED / 0:0`，实际 GPU 作业均在 H200 节点 `gpu38` 运行；本次查询时当前用户队列为空。

## 教师干预与全量结果

固定父实验第 17 层、TopK 64、seed 17 的 SAE。Dev 扫描 64 题、13 条件，共 832 条输出，选中 `short_rho0.3`：沿 8 个已确认短相关特征的 decoder 合成方向，从预测首个生成 token 的位置开始，施加相对 hidden norm 30% 的扰动。随机对照使用同数量 decoder 列和同范数。

另一组 64 题的三条件检验共 192 条输出。目标平均长度由 246.44 降至 209.23 tokens（−15.10%），无干预和目标均答对 64/64，随机答对 62/64；通过预登记教师门槛后，固定该条件执行全量生成，没有再按后续结果调参。

全量为 **881 题 × 三条件 × 四候选 = 10,572 条**，每个条件 3,524 条。以下是完整候选池结果，不是筛选后的正确子集：

| 条件 | 正确候选数 / 3,524 | 正确候选率 | 平均输出 tokens | 触及生成上限 |
| --- | ---: | ---: | ---: | ---: |
| 无干预 | 3,478 | 98.69% | 250.27 | 12 |
| SAE 短增强 | 3,485 | 98.89% | 217.07 | 1 |
| 匹配随机 | 3,443 | 97.70% | 293.02 | 38 |

目标相对无干预缩短 **13.27%**，平均每题候选长度差为 **−33.20 tokens**；以题目为重采样单位、保留题内四候选平均后的 95% bootstrap 区间为 **[−35.24, −31.22]**。正确候选率差为 **+0.20 个百分点**，区间 **[−0.43, +0.79]**，未确立正确率改善。全量统计是事后描述性汇总，没有改变入选门槛。

目标和随机的实际平均扰动范数比例均约为 0.3000，最大分别为 0.30028 / 0.30020，符合登记容差；实际干预覆盖全部存活生成位置。

![教师后续 64 题检验；非全量候选池](../results/ncsu_sae_intervention_v1/exploratory/analysis/test/teacher_comparison.png)

## 学生准确率

三个生成条件分别有 881 / 880 / 879 道题具备正确且未截断候选。对各条件去重后选择 shortest-correct，并与父实验自然 short 取共同支持，最终 **878/881 题**；剔除 `hf-000255`、`hf-000909`、`hf-001023`。四个条件均在该题集上重新训练。

学生固定 Qwen2.5-1.5B-Instruct、原 LoRA 超参数与 seeds 17/42/73。四条件 × 两预算 × 三种子，共 24 个 adapter；另有本轮 base。全部 25 组使用 GSM8K `test[50:1319]` 的 1,269 道题，greedy、512-token cap。

| 预算 | 无干预蒸馏 | SAE 蒸馏 | 匹配随机蒸馏 | 自然 short | SAE − 无干预（百分点，95% CI） |
| --- | ---: | ---: | ---: | ---: | ---: |
| 等样本 | 69.92% | **70.84%** | 68.87% | 66.93% | **+0.92 [−1.34, +3.23]** |
| 等目标 token | 70.42% | **70.34%** | 68.87% | 66.96% | **−0.08 [−2.18, +1.97]** |

表中准确率为三个训练 seed 的均值。本轮同环境 **Base 为 66.51%（844/1,269）**。

![学生准确率；黑点为三个训练 seed](../results/ncsu_sae_intervention_v1/exploratory/student_followup/analysis/student_comparison.png)

六项计划比较使用训练 seed 与配对题目的交叉 bootstrap，并一起作 Holm 校正：

| SAE 对照差（百分点） | 等样本：差值 [95% CI]；Holm p | 等 token：差值 [95% CI]；Holm p |
| --- | ---: | ---: |
| 相对无干预 | +0.92 [−1.34, +3.23]；0.8432 | −0.08 [−2.18, +1.97]；0.9654 |
| 相对匹配随机 | +1.97 [−0.29, +4.20]；0.3560 | +1.47 [−0.68, +3.55]；0.5418 |
| 相对自然 short | +3.91 [+1.71, +6.15]；0.0060 | +3.39 [+1.26, +5.52]；0.0110 |

**相对无干预和匹配随机，学生准确率收益均未确立。** 相对自然 short 的比较通过校正，但自然 short 来自父实验 16 候选的下 20% 长度带代表，本轮生成组使用新采样四候选中的 shortest-correct；采样与选样规则的差异使这一比较不能单独归因于 SAE 干预。

## 学生输出长度与预算

学生自身在完整评估上的平均输出长度如下；这些是描述性均值，不替代上述准确率检验。

| 预算 | 无干预蒸馏 | SAE 蒸馏 | 匹配随机 | 自然 short | SAE 相对无干预缩短 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 等样本 | 277.14 | 245.98 | 311.57 | 283.07 | 11.24% |
| 等目标 token | 276.55 | 245.31 | 311.57 | 282.14 | 11.30% |

Base 平均输出为 239.64 tokens。因此这里的缩短是相对无干预蒸馏学生而言，并非相对 base。

| 条件 | 等样本：记录 / completion tokens / 步数 | 等 token：记录 / completion tokens / 步数 |
| --- | ---: | ---: |
| 无干预 | 878 / 188,540 / 220 | 1,006 / 215,722 / 252 |
| SAE | 878 / 165,530 / 220 | 1,143 / 215,714 / 286 |
| 匹配随机 | 878 / 215,643 / 220 | 878 / 215,643 / 220 |
| 自然 short | 878 / 188,420 / 220 | 1,003 / 215,659 / 251 |

等 token 采用重复完整轨迹，四条件实际 token 总量相差至多 79；优化步数与题目权重不相等。随机条件本身就是最大 token 预算，两个预算下的数据相同；每个 seed 的两次随机 adapter 权重和预测均逐字节一致，不能把它们视作额外独立复现。

## 完成与复核证据

交付复核完成 **1,248 次哈希比对，覆盖 916 个已绑定文件、89 个完成标记**；包括冻结源码、教师/学生模型文件、最终 LoRA 文件与训练日志。另重新审计了 10,572 条生成记录、878 题共同支持、八份训练数据的 token 与题目权重、24 次训练步数和有效学习率，以及 **31,725 条评估记录**的顺序、唯一性、gold、答案判定和聚合指标，全部通过。生成、评估和交付报告的原始完成标记保留不变。

- [总完成标记](../results/ncsu_sae_intervention_v1/exploratory/INTERVENTION_COMPLETE.json)
- [最终交付审计](../results/ncsu_sae_intervention_v1/exploratory/setup/final_delivery_audit_20260913.json)
- [全部作业完成记录](../results/ncsu_sae_intervention_v1/exploratory/setup/completed_jobs_20260913.txt)
- [冻结执行协议](ncsu_sae_intervention_v1.md)
- [Dev 报告](../results/ncsu_sae_intervention_v1/exploratory/analysis/dev/report_zh.md)、[Test 报告](../results/ncsu_sae_intervention_v1/exploratory/analysis/test/report_zh.md)
- [全量候选与预算审计](../results/ncsu_sae_intervention_v1/exploratory/student_followup/data_audit.json)
- [学生原始报告](../results/ncsu_sae_intervention_v1/exploratory/student_followup/analysis/report_zh.md)、[学生统计](../results/ncsu_sae_intervention_v1/exploratory/student_followup/analysis/summary.json)
- [最终 adapter 目录](../checkpoints/ncsu_sae_intervention_v1/student_followup/students/)

## 适用范围

本轮保持探索性 GSM8K 结论，`formal_claim_allowed=false`；只有一个 SAE seed，使用已观察过的题集。答案格式关联尚未排除，不能把这些特征称为已识别的“简洁推理能力”。教师 64 题全部正确不能证明总体正确率无损；对应经验正确率 bootstrap 区间退化为零，也不能作为总体风险的精确界限。

本轮 H200 base 66.51% 与前轮 H100 base 67.45% 是分别执行的结果；差异来源未隔离，保留各自基线，不直接混用。当前证据支持教师及相对无干预蒸馏学生的输出缩短，尚不支持 SAE 带来稳定的学生准确率增益。
